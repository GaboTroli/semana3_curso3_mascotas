package com.gabriel.tarea_semana3_curso3;

import android.app.Activity;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //TextView likes;
    int visitado = 0;
    ImageButton huesoLike;
    Button estrella;
    Button flechaReturn;
    private RecyclerView listaMascotas;
    ArrayList<Mascota> mascotas;
    String[] arrayLikes=new String[5];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        listaMascotas=(RecyclerView) findViewById(R.id.reciclerViewMio);

        huesoLike = findViewById(R.id.huesoLikeIV);

        flechaReturn = findViewById(R.id.flechaReturnBtn);
        flechaReturn.setVisibility(View.INVISIBLE);

        estrella = findViewById(R.id.estrellaNuevaPantalla);
        estrella.setVisibility(View.VISIBLE);

        estrella.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nuevaPantalla();
            }
        });


        Toolbar miActionBar = (Toolbar) findViewById(R.id.actionBarMia2);
        setSupportActionBar(miActionBar);


        LinearLayoutManager llm=new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);


       Bundle parametros = getIntent().getExtras();
       if(parametros != null){
           visitado = Integer.parseInt(parametros.getString("visitado2"));
           arrayLikes = parametros.getStringArray("arrayLikes");
       }

        inicializarContactos();
        inicializarAdaptador();

    }


    public void nuevaPantalla()
    {
        Button apoyo;
        apoyo = findViewById(R.id.botonApoyoCambioActivity);
        apoyo.callOnClick(); //clickea el boton apoyo que se encuentra en el adaptador y desde ahí se cambia el intent

    }

    public void inicializarAdaptador(){

        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,this);
        listaMascotas.setAdapter(adaptador);

    }

    public void inicializarContactos () {
        mascotas = new ArrayList<Mascota>();
        String[] nombre = new String[5];
        nombre[0]="Tommy";nombre[1]="Fido";nombre[2]="Rocky";nombre[3]="Giro";nombre[4]="Bola de pelo ";

        if(visitado==2){
            for(int x=0;x<5;x++) {
                    if (x == 0) {
                        mascotas.add(new Mascota(R.drawable.perro1, nombre[x], R.drawable.hueso1, Integer.parseInt((String) arrayLikes[x])));
                    }
                    if (x == 1) {
                        mascotas.add(new Mascota(R.drawable.perro2, nombre[x], R.drawable.hueso1, Integer.parseInt((String) arrayLikes[x])));
                    }
                    if (x == 2) {
                        mascotas.add(new Mascota(R.drawable.perro3, nombre[x], R.drawable.hueso1, Integer.parseInt((String) arrayLikes[x])));
                    }
                    if (x == 3) {
                        mascotas.add(new Mascota(R.drawable.gato1, nombre[x], R.drawable.hueso1, Integer.parseInt((String) arrayLikes[x])));
                    }
                    if (x == 4) {
                        mascotas.add(new Mascota(R.drawable.gato2, nombre[x], R.drawable.hueso1, Integer.parseInt((String) arrayLikes[x])));
                    }
            }
        }

        if(visitado ==0){
            mascotas.add(new Mascota(R.drawable.perro1,"Tommy",R.drawable.hueso1,0));
            mascotas.add(new Mascota(R.drawable.perro2,"Fido",R.drawable.hueso1,0));
            mascotas.add(new Mascota(R.drawable.perro3,"Rocky",R.drawable.hueso1,0));
            mascotas.add(new Mascota(R.drawable.gato1,"Giro",R.drawable.hueso1,0));
            mascotas.add(new Mascota(R.drawable.gato2,"Bola de pelo",R.drawable.hueso1,0));
            visitado=2;
        }


    }


}
