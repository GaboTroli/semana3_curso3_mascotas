package com.gabriel.tarea_semana3_curso3;

public class Mascota {
    //atributos
    private String nombre;
    private Boolean like;
    private int foto;
    private int numLikes;
    private int huesoAmarillo;

    //constructor
    public Mascota(int foto, String nombre,int huesoAmarillo,int numLikes)
    {
        this.foto=foto;
        this.like=false;
        this.nombre=nombre;
        this.numLikes= numLikes;
        this.huesoAmarillo=huesoAmarillo;

    }

    //getters and setters


    public int getHuesoAmarillo() {
        return huesoAmarillo;
    }

    public void setHuesoAmarillo(int huesoAmarillo) {
        this.huesoAmarillo = huesoAmarillo;
    }

    public int getNumLikes() {
        return numLikes;
    }

    public void setNumLikes(int numLikes) {
        this.numLikes = numLikes;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public Boolean getLike() {
        return like;
    }

    public void setLike(Boolean like) {
        this.like = like;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
