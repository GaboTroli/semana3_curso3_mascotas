package com.gabriel.tarea_semana3_curso3;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;


public class MascotaAdaptador extends RecyclerView.Adapter<MascotaAdaptador.MascotaViewHolder> {

    private ArrayList<Mascota> mascotas;
    /*
    private ArrayList<String> PosicionUltimosLikesArray = new ArrayList<String>(); //es para saber cuales fueron los ultimos 5 en tener like
    private ArrayList<String> PosicionArray = new ArrayList<String>(); //para saber la posición de la tarjeta que tiene like
    private ArrayList<String> LikeArray =  new ArrayList<String>();*/
    String[][] arrayCombinado = new String [5][2]; //[número de cardView] [numero de likes]
    String [] arrayLikes = new String[5]; //corresponde a los 5 posibles cV con su numero de likes
    String [] arrayPosicion = new String[5];
    private int ultimo5likesPosicion = 0;
     //Activity mainActivity;

    private final Context context;


    public MascotaAdaptador(ArrayList<Mascota> mascotas,Context context){

        this.mascotas = mascotas;
        this.context=context;
        for(int x=0;x<5;x++){
            for(int y=0;y<2;y++){
                arrayCombinado[x][y]="0";
            }
        }

    }




    //inflar el layout y lo pasara al viewholder para que obtenga los views
    @NonNull
    @Override
    public MascotaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view,parent,false);
        return new MascotaViewHolder(v);
    }


    //asocia cada elemento de la lista con cada view
    //así mismo desde este metodo podemos modificar los elementos y crear los onclickListener
    @Override
    public void onBindViewHolder(@NonNull final MascotaAdaptador.MascotaViewHolder mascotaViewHolder, final int position) {

        final Mascota mascota = mascotas.get(position);
        String numeroDeLikesString = Integer.toString(mascota.getNumLikes());

        mascotaViewHolder.imgFoto.setImageResource(mascota.getFoto());
        mascotaViewHolder.txtvNombre.setText(mascota.getNombre());
        mascotaViewHolder.numLikes.setText(numeroDeLikesString);
        mascotaViewHolder.huesoAmarilloLike.setBackgroundResource(mascota.getHuesoAmarillo());
        mascotaViewHolder.huesoAmarilloLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Integer.parseInt((String)mascotaViewHolder.numLikes.getText()) < 4 ) {
                    mascotaViewHolder.huesoAmarilloLike.setBackgroundResource(R.drawable.huesoamarillo2);
                    int like = Integer.parseInt((String) mascotaViewHolder.numLikes.getText());
                    like++;
                    String likeString = Integer.toString(like);
                    mascotaViewHolder.numLikes.setText(likeString);
                    String posicion = String.valueOf(mascotaViewHolder.getPosition());
                    //Toast.makeText(context,"The Item Clicked is: "+ posicion,Toast.LENGTH_SHORT).show();

                    arrayCombinado[mascotaViewHolder.getPosition()][0] = (String) mascotaViewHolder.numLikes.getText();
                    arrayCombinado[mascotaViewHolder.getPosition()][1] = Integer.toString(ultimo5likesPosicion);
                }

                //Toast.makeText(context, String.valueOf(arrayLikes[2]), Toast.LENGTH_SHORT).show();

            } //Termina OnClick()
        });

        mascotaViewHolder.botonApoyoCambioActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View view) {

                for (int x=0;x<5;x++){
                    arrayLikes[x] = arrayCombinado[x][0];
                    arrayPosicion[x] = arrayCombinado[x][1];
                }
                /*
                if(){
                    for (int x=0;x<5;x++){
                        arrayLikes[x] = (String) mascotaViewHolder.numLikes.getText();
                    }
                }*/

                mascotaViewHolder.botonApoyoCambioActivity.setVisibility(View.INVISIBLE);

                Intent intent = new Intent(context,mascotas_favoritas.class);
                intent.putExtra("arrayLikes",arrayLikes);
                intent.putExtra("arrayPosicion",arrayPosicion);

                //falta mandar todos los datos a el activity masctoas_favoritas, una vez abierto cuando se inicie el recycler view se hará con los datos mandados
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        //nos devuelve la cantidad de elementos
        return mascotas.size();
    }



    public  class MascotaViewHolder extends RecyclerView.ViewHolder{

        //aqui voy a declarar mis views
        private ImageView imgFoto;
        private TextView txtvNombre;
        private TextView numLikes;
        private ImageButton huesoAmarilloLike;
        private Button botonApoyoCambioActivity;


        public MascotaViewHolder(View itemView) {
            super(itemView);
           // final Context context;
            imgFoto = (ImageView) itemView.findViewById(R.id.PerroFotoIMV);
            txtvNombre = (TextView) itemView.findViewById(R.id.nombreCvTexto);
            numLikes = (TextView) itemView.findViewById(R.id.numeroLikesTv);
            huesoAmarilloLike = (ImageButton) itemView.findViewById(R.id.huesoLikeIV);
            botonApoyoCambioActivity = itemView.findViewById(R.id.botonApoyoCambioActivity);



        }
    }

}
