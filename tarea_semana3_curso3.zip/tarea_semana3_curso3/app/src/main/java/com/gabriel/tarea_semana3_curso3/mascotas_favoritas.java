package com.gabriel.tarea_semana3_curso3;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.support.annotation.VisibleForTesting;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class mascotas_favoritas extends AppCompatActivity {

    Button estrellaToolbar;
    Button flechaBtn;
    private RecyclerView listaMascotas;
    ArrayList<Mascota> mascotas;
    String [] arrayPosicion = new String [5];
    String [] arrayLikes = new String[5];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascotas_favoritas);

        Toolbar miActionBar = (Toolbar) findViewById(R.id.actionBarMia2);
        setSupportActionBar(miActionBar);
        listaMascotas=(RecyclerView) findViewById(R.id.reciclerViewMio);
        LinearLayoutManager llm=new LinearLayoutManager(mascotas_favoritas.this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);



        //Toast.makeText(this, ArrayLikes.size(), Toast.LENGTH_SHORT).show();
        flechaBtn = findViewById(R.id.flechaReturnBtn);
        flechaBtn.setVisibility(View.VISIBLE);

        flechaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                regresar();
            }
        });
        estrellaToolbar = findViewById(R.id.estrellaNuevaPantalla);
        estrellaToolbar.setVisibility(View.INVISIBLE);

        inicializarContactos();
        inicializarAdaptador();
    }

    public void regresar() {

        Intent intent = new Intent(mascotas_favoritas.this, MainActivity.class);

        intent.putExtra("visitado2","2");
        intent.putExtra("arrayLikes",arrayLikes);
        startActivity(intent);
        finish();
    }



    public void inicializarAdaptador(){

        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,mascotas_favoritas.this);
        listaMascotas.setAdapter(adaptador);
    }


    public void inicializarContactos () {
        mascotas = new ArrayList<Mascota>();
        Bundle parametros = getIntent().getExtras();
        if (parametros != null)
        {

           arrayLikes = parametros.getStringArray("arrayLikes");
           //Toast.makeText(mascotas_favoritas.this, arrayLikes[1], Toast.LENGTH_SHORT).show();

        }

        String[] nombre = new String[5];
        nombre[0]="Tommy";nombre[1]="Fido";nombre[2]="Rocky";nombre[3]="Giro";nombre[4]="Bola de pelo ";


        for(int x=0; x<5 ; x++){
            if(!arrayLikes[x].equals("0")){
                if(x==0){
                    mascotas.add(new Mascota(R.drawable.perro1,nombre[x],R.drawable.huesoamarillo2,Integer.parseInt((String)arrayLikes[x])));
                }
                if(x==1){
                    mascotas.add(new Mascota(R.drawable.perro2,nombre[x],R.drawable.huesoamarillo2,Integer.parseInt((String)arrayLikes[x])));
                }
                if(x==2){
                    mascotas.add(new Mascota(R.drawable.perro3,nombre[x],R.drawable.huesoamarillo2,Integer.parseInt((String)arrayLikes[x])));
                }
                if(x==3){
                    mascotas.add(new Mascota(R.drawable.gato1,nombre[x],R.drawable.huesoamarillo2,Integer.parseInt((String)arrayLikes[x])));
                }
                if(x==4){
                    mascotas.add(new Mascota(R.drawable.gato2,nombre[x],R.drawable.huesoamarillo2,Integer.parseInt((String)arrayLikes[x])));
                }

            }
        }
    }
}
